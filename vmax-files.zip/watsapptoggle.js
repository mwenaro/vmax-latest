
function menuToggle(){
  const toggleMenu = document.querySelector(".whatsapp-fluid");
  toggleMenu.classList.toggle('active')
}
